# KA-CHOW
*Kilowatt Analyzing Car Health Optimization Widget*

## How to Use
To run the simulator, run the command ```python sim.py [track.json]```
    - The current track file used is track2.json.