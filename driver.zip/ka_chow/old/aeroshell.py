# model of the aeroshell

#class Aeroshell: