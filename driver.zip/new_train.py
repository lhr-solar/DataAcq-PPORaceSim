from fixed_gym import *
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

gym.register(
    id="SolarCar-v0",
    entry_point="solar_car_2:SolarCar",
    max_episode_steps=2500,
)

env = make_vec_env("SolarCar-v0", n_envs=1,
                   env_kwargs=dict(render_mode="human"))

model = PPO("MlpPolicy", env, verbose=1, tensorboard_log='log')

model.learn(total_timesteps=10000)

model.save("ppo_car_racing")
