class Electronics:
    
    def __init__(self):
        self.current = 63.4

    def run(self):
        return self.current
