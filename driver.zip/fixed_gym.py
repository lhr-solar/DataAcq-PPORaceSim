import sys
import gymnasium as gym
sys.modules["gym"] = gym
